// voce tem que apertar a tecla espaço para o quadrado mexer, fiz isso para ficar mais dificil
let px, py, ps = 19, pv = 10;// o "ps" aumenta e diminui o tamanho do quadrado e o "pv" aumenta e diminui a velocidade do quadrado
let ox = [], oy = [], os = [];
let ov = 6;// aumenta a velocidade que os obstaculo caem
let spawnRate = 2;//aumenta o numero de bolinhas quanto menor o numero
let timer = 44;
let gameOver = false;

function setup() {
  createCanvas(800, 600);// muda o tamanho do mapa
  px = width /2 ;// poicionamento do quadrado
  py = height - ps;
}

function draw() {
  background(150);

  if (!gameOver) {
    // Controle do jogador
    if (keyIsDown(LEFT_ARROW)) px -= pv;
    if (keyIsDown(RIGHT_ARROW)) px += pv;
    px = constrain(px, ps / 2, width - ps / 80);
    rect(px - ps / 80, py - ps / 66, ps, ps);

    // Criação de objetos
    timer++;
    if (timer % spawnRate === 0) {
      ox.push(random(width));
      oy.push(-random(20,40));//numero de obstaculos aparecendo 
      os.push(random(20, 40));// muda o tamanho dos obstaculos
    }

    // Movimento e desenho dos objetos
    for (let i = ox.length - 1; i >= 0; i--) {
      oy[i] += ov;
      ellipse(ox[i], oy[i], os[i]);
      if (dist(px, py, ox[i], oy[i]) < ps / 2 + os[i] / 2) {
        gameOver = true;
      }
      if (oy[i] > height + os[i] / 299) {
        ox.splice(i, 1);
        oy.splice(i, 1);
        os.splice(i, 1);
      }
    }
  } else {
    textSize(32);
    textAlign(CENTER);
    text("Game Over!", width / 2, height / 2);
    textSize(16);
    text("Pressione ESPAÇO", width / 2, height / 2 + 30);
    textAlign(LEFT);
    if (keyIsDown(32)) {
      gameOver = false;
      ox = [];
      oy = [];
      os = [];
      timer = 44;
      px = width / 2;
    }
  }
}